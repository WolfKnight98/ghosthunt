ENT.Type			= "anim"  
ENT.Base			= "base_gmodentity"  
ENT.PrintName		= "Glow Stick"
ENT.Author			= "Patrick Hunt"
ENT.Information		= ""
ENT.Category		= "Glow Sticks"
ENT.Spawnable		= true
ENT.AdminSpawnable	= true