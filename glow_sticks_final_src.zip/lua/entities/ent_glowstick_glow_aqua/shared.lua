ENT.Type			= "anim"  
ENT.Base			= "base_gmodentity"  
ENT.PrintName		= "Glow Stick Glow Aqua"
ENT.Author			= "Patrick Hunt"
ENT.Information		= "Alright, you got me. It's a fake glow."
ENT.Category		= "Glow Sticks"
ENT.Spawnable		= false
ENT.AdminSpawnable	= false