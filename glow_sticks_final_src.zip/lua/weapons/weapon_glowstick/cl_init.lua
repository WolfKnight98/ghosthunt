include('shared.lua')

SWEP.Slot			= 1; 
SWEP.SlotPos		= 1; 
SWEP.Spawnable		= true
SWEP.AdminSpawnable	= true
SWEP.WepSelectIcon	= surface.GetTextureID( "vgui/entities/glowstick" )